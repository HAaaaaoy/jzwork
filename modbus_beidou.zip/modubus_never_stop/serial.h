// serial.h
#ifndef SERIAL_H
#define SERIAL_H
#include <stdint.h>
#include <termios.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>

typedef struct {
    int fd;
    pthread_mutex_t lock;
    void (*callback)(const uint8_t *, int);  // 数据回调函数指针
} SerialPort;

int serial_open(SerialPort *port, const char *dev, int baudrate);
void serial_close(SerialPort *port);
void serial_set_callback(SerialPort *port, void (*cb)(const uint8_t *, int));
int serial_write(SerialPort *port, const uint8_t *buf, int len);
int serial_set();


#endif
