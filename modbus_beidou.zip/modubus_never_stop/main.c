// main.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include "serial.h"
#include "modbus_utils.h"

#define TARGET_LEN 21
#define MAX_BUF_LEN 256

uint8_t re_buf[MAX_BUF_LEN];
uint16_t rx_index = 0;

SerialPort port;
volatile int running = 1;


// Modbus请求帧（固定值）
const uint8_t modbus_request[] = {0x01, 0x03, 0x00, 0x01, 0x00, 0x01, 0xD5, 0xCA};
//const uint8_t modbus_request_beidou[] = {0x01, 0x03, 0x10, 0x00, 0x45, 0x42, 0xD1, 0x58, 0x74, 0x00, 0x4E, 0x41,
 //       0xFB, 0xF3, 0x80, 0x45, 0xAB, 0x60, 0x00, 0x2B, 0xB7};
 const uint8_t modbus_request_beidou[] = {0x01, 0x03, 0x00, 0x18, 0x00, 0x08, 0xC4, 0x0B};

void modbus_parse_mode(const uint8_t *modbus_data, GPSData gps, const int model)
{
	if (model == 1) {
		printf("=== 不校验CRC直接解析 ===\n");

		if (parse_modbus_gps(modbus_data, sizeof(modbus_data), &gps) == 0) {

			print_gps_data(&gps);
		}
    }
	
    // 方式2：带CRC校验的完整解析
	else if (model == 2) {
		printf("\n=== 带CRC校验解析 ===\n");
		if (parse_modbus_gps_with_crc(modbus_data, 19, &gps) == 0) {
			print_gps_data(&gps);
		} else {
			printf("CRC校验失败！\n");
		}
	}
    
    // 单独使用CRC校验功能
	else {
		printf("\n=== 单独计算CRC ===\n");
		uint16_t crc = modbus_crc16(modbus_data, sizeof(modbus_data)-2);
		printf("计算出的CRC: 0x%04X\n", crc);
		printf("帧中的CRC: 0x%02X%02X\n", 
			   modbus_data[sizeof(modbus_data)-1], 
			   modbus_data[sizeof(modbus_data)-2]);
	}
}

// 数据接收回调函数
void on_data_received(const uint8_t *data, int len) {
    printf("RX %d bytes: ", len);
    for (int i = 0; i < len; i++) {
        printf("%02X ", data[i]);  // 大写十六进制，空格分隔
    }
    printf("\n");  // 换行
    
    GPSData gps;
    
    modbus_parse_mode(data, gps, 1);
}

void signal_handler(int sig) {
    running = 0;
}

int main() {
    signal(SIGINT, signal_handler);

    // 1. 初始化串口（9600波特率）
    if (serial_open(&port, "/dev/ttyS1", B115200) < 0) {
        perror("Failed to open /dev/ttyS1");
        return 1;
    }

    // 2. 设置数据回调
    serial_set_callback(&port, on_data_received);

    // 3. 主循环：每20秒发送一次Modbus请求
    while (running) {
        if (serial_write(&port, modbus_request_beidou, sizeof(modbus_request_beidou)) != sizeof(modbus_request_beidou)) {
            perror("write failed");
            break;
        }
        sleep(20); //wait 20s
    }

    // 4. 清理
    serial_close(&port);
    printf("Program terminated.\n");
    return 0;
}
