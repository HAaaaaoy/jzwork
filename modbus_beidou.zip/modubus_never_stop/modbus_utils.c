#include "modbus_utils.h"

/* CRC16计算表（Modbus标准），未写完，需要补充*/
static uint16_t crc16_table[256];

/*使用当前init_crc16_table函数补充*/
static void init_crc16_table() {
    for (int i = 0; i < 256; i++) {
        uint16_t crc = i;
        for (int j = 0; j < 8; j++) {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xA001;
            else
                crc >>= 1;
        }
        crc16_table[i] = crc;
    }
}

uint16_t modbus_crc16(const uint8_t *data, uint16_t length) {
	init_crc16_table();//初始化建立完整的crc16_table
    uint16_t crc = 0xFFFF;
    while (length--) {
        crc = (crc >> 8) ^ crc16_table[(crc ^ *data++) & 0xFF];
    }
    return ((crc & 0xFF) << 8) | (crc >> 8); //CRC校验数据低字节在前，高字节在后
}

int verify_modbus_crc(const uint8_t *data, uint16_t length) {
    if (length < 2) return -1;
    
    uint16_t received_crc = (data[length-1] << 8) | data[length-2];
    uint16_t calculated_crc = modbus_crc16(data, length-2);
    
    return (received_crc == calculated_crc) ? 0 : -1;
}

static float parse_float_be(const uint8_t *data) {
    FloatUnion fu;

    fu.bytes[0] = data[3];
    fu.bytes[1] = data[2];
    fu.bytes[2] = data[1];
    fu.bytes[3] = data[0];
    return fu.f;
}

int parse_modbus_gps(const uint8_t *data, int len, GPSData *result) {
	len = 19;
   
    if (len < 18 || !data || !result) return -1;
    result->longitude_dir = ((data[3] << 8) | data[4]) == 0x0045 ? 'E' : 'W';
    result->longitude = parse_float_be(&data[5]);
    result->latitude_dir = ((data[9] << 8) | data[10]) == 0x004E ? 'N' : 'S';
    result->latitude = parse_float_be(&data[11]);
    result->altitude = parse_float_be(&data[15]);
    return 0;
}

int parse_modbus_gps_with_crc(const uint8_t *data, uint16_t len, GPSData *result) {
    if (verify_modbus_crc(data, len) != 0) {
        return -1; // CRC校验失败
    }
    return parse_modbus_gps(data, len-2, result); // 去除CRC字节后解析
}

void print_gps_data(const GPSData *gps) {
    printf("经度: %.6f°%c\n", gps->longitude, gps->longitude_dir);
    printf("纬度: %.6f°%c\n", gps->latitude, gps->latitude_dir);
    printf("高度: %.2f米\n", gps->altitude);
}
