// serial.c
#include "serial.h"


// 串口接收线程函数
static void *receive_thread(void *arg) {
    SerialPort *port = (SerialPort *)arg;
    uint8_t buf[1024];
    
    while (1) {
        int len = read(port->fd, buf, sizeof(buf));
        if (len > 0 && port->callback) {
            port->callback(buf, len);  // 触发回调
        } else if (len < 0) {
            perror("Serial read error");
            break;
        }
    }
    return NULL;
}

int serial_open(SerialPort *port, const char *dev, int baudrate) {
    port->fd = open(dev, O_RDWR | O_NOCTTY);
    if (port->fd < 0) return -1;

    pthread_mutex_init(&port->lock, NULL);
    port->callback = NULL;

    struct termios tty;
    tcgetattr(port->fd, &tty);
    cfsetispeed(&tty, baudrate);
    cfsetospeed(&tty, baudrate);
    tty.c_cflag &= ~PARENB;    // 无校验
    tty.c_cflag &= ~CSTOPB;    // 1位停止位
    tty.c_cflag |= CS8;        // 8位数据位
    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);  // 原始模式
    tty.c_iflag &= ~(IXON | IXOFF | IXANY | IGNBRK); // 禁用软件流控和BREAK处理
    tty.c_oflag &= ~OPOST;                           // 原始输出    
    tty.c_cc[VTIME] = 20;  // 超时0.5秒（单位：0.1秒）
	tty.c_cc[VMIN] = 21;  // 至少读取10字节才返回
    tcsetattr(port->fd, TCSANOW, &tty);

    // 启动接收线程
    pthread_t tid;
    pthread_create(&tid, NULL, receive_thread, port);
    pthread_detach(tid);  // 分离线程，避免资源泄漏

    return 0;
}

void serial_close(SerialPort *port) {
    pthread_mutex_destroy(&port->lock);
    close(port->fd);
}

void serial_set_callback(SerialPort *port, void (*cb)(const uint8_t *, int)) {
    port->callback = cb;
}

int serial_write(SerialPort *port, const uint8_t *buf, int len) {

    pthread_mutex_lock(&port->lock);
    int n = write(port->fd, buf, len);
    pthread_mutex_unlock(&port->lock);
    return n;
}
