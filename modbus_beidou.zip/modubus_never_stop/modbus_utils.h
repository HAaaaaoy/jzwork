#ifndef MODBUS_UTILS_H
#define MODBUS_UTILS_H

#include <stdio.h>
#include <stdint.h>

// GPS数据结构体
typedef struct {
    float longitude;      // 经度值
    char longitude_dir;   // 经度方向(E/W)
    float latitude;       // 纬度值
    char latitude_dir;    // 纬度方向(N/S)
    float altitude;       // 高度(米)
} GPSData;

// 联合体用于浮点数转换
typedef union {
    float f;
    uint8_t bytes[4];
} FloatUnion;


/**
 * @brief Modbus CRC16校验计算
 * @param data 数据指针
 * @param length 数据长度
 * @return 计算出的CRC16值
 */
uint16_t modbus_crc16(const uint8_t *data, uint16_t length);

/**
 * @brief 验证Modbus数据CRC
 * @param data 包含CRC的完整数据帧
 * @param length 数据总长度(含CRC)
 * @return 0校验成功，-1校验失败
 */
int verify_modbus_crc(const uint8_t *data, uint16_t length);

/**
 * @brief 解析Modbus GPS数据（不校验CRC）
 * @param data 原始Modbus数据数组
 * @param len 数据长度
 * @param result 解析结果输出
 * @return 0成功，-1失败
 */
int parse_modbus_gps(const uint8_t *data, int len, GPSData *result);

/**
 * @brief 完整解析（带CRC校验）
 * @param data 完整数据帧
 * @param len 数据总长度
 * @param result 解析结果输出
 * @return 0成功，-1失败
 */
int parse_modbus_gps_with_crc(const uint8_t *data, uint16_t len, GPSData *result);

/**
 * @brief 打印GPS数据
 * @param gps 要打印的数据
 */
void print_gps_data(const GPSData *gps);

#endif
